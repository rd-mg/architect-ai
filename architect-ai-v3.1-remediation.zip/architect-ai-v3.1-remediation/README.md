# Architect-AI V3.1 Remediation Package

**Version**: 3.1 | **Date**: 2026-04-17 | **Target**: Apply on top of a V3-installed `architect-ai` repo

This package is a **delta** over the V3 package. It does **not** replace V3 — it fixes the 6 verified findings post-V3 install:

| # | Finding | Root cause | Phase |
|---|---------|-----------|-------|
| 1 | 4 docs missing in V3 package | README declared 50 files, zip had 46 | A |
| 2 | Session never asks engram/openspec/hybrid/none | Auto-detect silent; question only lived in `sdd-onboard` | B |
| 3 | "usa sdd" skips cycle or runs single phase | No natural-language intent resolution | C |
| 4 | TUI has no deep "Uninstall & Purge All" | `uninstall` only removes managed config | D |
| 5 | Token-from-cache banner gone at session end | Regression — no metering pkg exists | E |
| 6 | `ripgrep` and `bash-expert` not forced into sub-agents | No `bridge: always` mechanism | F |

Also bundled: **research routing policy** — NotebookLM first → local code/docs → Context7 → Internet only on explicit user request.

---

## How to Apply

### Option 1 — Automated (recommended)

```bash
cd /path/to/architect-ai
unzip /path/to/architect-ai-v3.1-remediation.zip -d /tmp/v3.1
bash /tmp/v3.1/architect-ai-v3.1-remediation/scripts/apply.sh .
go test ./...
git diff --stat
git add -A && git commit -m "[IMP][v3.1] remediation: 6 findings + research routing"
```

### Option 2 — Manual

Follow `plans/v3.1-remediation-plan.md` step by step. Each file in `code/` maps 1:1 to its target path in the `architect-ai` repo (drop `code/` prefix, path is identical).

Files in `patches/` are unified-diff-style snippets describing changes to existing files that were too large to ship whole. Apply them with `patch -p1 < patches/{name}.patch` or manually.

---

## Package Contents (32 files)

### Plans (1)
- `plans/v3.1-remediation-plan.md` — the detailed roadmap

### Documentation (5)
- `docs/README.refactored.md` — cleaned-up main repo README (replaces root `README.md`)
- `code/docs/cognitive-modes.md` — 6 postures reference (was missing in V3)
- `code/docs/caveman-integration.md` — dual-mode output compression (was missing)
- `code/docs/adaptive-reasoning-v1.md` — absorbed judgment-day + autoreason-lite (was missing)
- `code/docs/antigravity-sdd-workaround.md` — single-thread simulation workaround (was missing)

### Skills (5)
- `code/internal/assets/skills/ripgrep/SKILL.md` — NEW, `bridge: always`
- `code/internal/assets/skills/bash-expert/SKILL.md` — NEW, `bridge: always`
- `code/internal/assets/skills/mcp-notebooklm-orchestrator/SKILL.md` — v2.1, primary research source
- `code/internal/assets/skills/mcp-context7-skill/SKILL.md` — v2.1, defers to NotebookLM
- `code/internal/assets/skills/_shared/research-routing.md` — NEW shared fragment

### Orchestrators (8 agents)
- `code/internal/assets/claude/sdd-orchestrator.md` — CANONICAL (all fixes embedded)
- `code/internal/assets/antigravity/sdd-orchestrator.md`
- `code/internal/assets/codex/sdd-orchestrator.md`
- `code/internal/assets/cursor/sdd-orchestrator.md`
- `code/internal/assets/gemini/sdd-orchestrator.md`
- `code/internal/assets/generic/sdd-orchestrator.md`
- `code/internal/assets/kiro/sdd-orchestrator.md`
- `code/internal/assets/opencode/sdd-orchestrator.md`

### Phase protocol update (1)
- `code/internal/assets/claude/sdd-phase-protocols/sdd-explore.md` — research routing injected

### Go — new packages & files (9)
- `code/internal/metering/session_stats.go` — NEW
- `code/internal/metering/pricing.go` — NEW
- `code/internal/metering/hook.go` — NEW
- `code/internal/metering/session_stats_test.go` — NEW
- `code/internal/components/uninstall/purge.go` — NEW (DeepPurge impl)
- `code/internal/tui/screens/purge.go` — NEW
- `code/internal/tui/screens/purge_confirm.go` — NEW
- `code/internal/tui/screens/purge_result.go` — NEW
- `code/internal/agents/claude/adapter_metering.go` — NEW (canonical reference)

### Go — full replacements (1)
- `code/internal/tui/screens/welcome.go` — adds "Uninstall & Purge All ⚠" option

### Patches (7)
- `patches/uninstall-service.patch` — adds `DeepPurge` entry point
- `patches/skill-resolver.patch` — respects `bridge: always`
- `patches/tui-model.patch` — adds purge screens enum
- `patches/tui-router.patch` — wires purge routes
- `patches/cli-uninstall.patch` — adds `--purge` flag
- `patches/agents-interface.patch` — adds `MeteringCapable`
- `patches/adapter-metering-template.md` — per-agent instructions for adapter_metering.go generation

### Scripts (2)
- `scripts/apply.sh` — one-shot applier
- `scripts/generate-agent-metering.sh` — generates per-agent metering adapter stubs

---

## Verification after applying

```bash
# 1. Build + test
go test ./...

# 2. Visual — welcome screen shows purge
architect-ai
# Expected menu item: "Uninstall & Purge All ⚠"

# 3. Intent resolution — in Claude Code (or any agent)
# Type: "usa sdd"
# Expected: orchestrator asks for change name + artifact store + execution mode, then runs full cycle

# 4. Bridge: always — resolve skills
architect-ai skill-registry
grep "bridge: always" .atl/skill-registry.md
# Expected: ripgrep + bash-expert listed

# 5. Token cache banner — end a session with ctrl+c
# Expected: summary banner with "From cache: X (Y%)"
```

---

## Rollback

Every change is in a single commit. Rollback is just `git revert <commit>`. Binaries are not touched — the `uninstall --purge` opt-in is what removes binaries.

---

## Credits

Package hand-crafted for `rd-mg/architect-ai` as a V3.1 remediation. No data flows outside the repo clone + user's filesystem.
