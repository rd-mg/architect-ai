#!/usr/bin/env bash
# apply.sh — applies the V3.1 remediation delta to a cloned architect-ai repo.
#
# Usage:
#   bash apply.sh /path/to/architect-ai
#
# Safe to re-run — each step is idempotent (files are copied with cp -f).
# Does NOT run `git commit`; that's the operator's decision.

set -euo pipefail
IFS=$'\n\t'

if [[ $# -lt 1 ]]; then
    echo "Usage: bash apply.sh /path/to/architect-ai" >&2
    exit 64
fi

TARGET="${1%/}"
DELTA="$(cd "$(dirname "$0")/.." && pwd)"

if [[ ! -d "$TARGET" ]]; then
    echo "Target directory does not exist: $TARGET" >&2
    exit 66
fi

if [[ ! -f "$TARGET/go.mod" ]]; then
    echo "Target does not look like a Go project (no go.mod): $TARGET" >&2
    exit 66
fi

if [[ ! -d "$DELTA/code" ]]; then
    echo "Delta package missing 'code/' directory. Re-extract the zip." >&2
    exit 70
fi

echo "==> Architect-AI V3.1 Remediation"
echo "    Target: $TARGET"
echo "    Delta:  $DELTA"
echo

# Preflight — target must be clean
pushd "$TARGET" >/dev/null
if [[ -n "$(git status --porcelain 2>/dev/null || true)" ]]; then
    echo "WARN: target has uncommitted changes. Continue? (y/N)" >&2
    read -r reply
    case "$reply" in
        [yY]) ;;
        *) echo "Aborted."; exit 1 ;;
    esac
fi
popd >/dev/null

# Phase A — docs (4 files)
echo "==> Phase A: missing V3 docs"
mkdir -p "$TARGET/docs"
cp -f "$DELTA/code/docs/cognitive-modes.md"            "$TARGET/docs/cognitive-modes.md"
cp -f "$DELTA/code/docs/caveman-integration.md"        "$TARGET/docs/caveman-integration.md"
cp -f "$DELTA/code/docs/adaptive-reasoning-v1.md"      "$TARGET/docs/adaptive-reasoning-v1.md"
cp -f "$DELTA/code/docs/antigravity-sdd-workaround.md" "$TARGET/docs/antigravity-sdd-workaround.md"
echo "    ✓ 4 doc files written"

# Phase A (continued) — README refactor
echo "==> Phase A.2: root README refactor"
if [[ -f "$DELTA/docs/README.refactored.md" ]]; then
    cp -f "$DELTA/docs/README.refactored.md" "$TARGET/README.md"
    echo "    ✓ README.md replaced"
else
    echo "    ⚠  README.refactored.md not in delta; skipped"
fi

# Phases B + C + F + G — orchestrators (8 agents)
echo "==> Phases B+C+F+G: 8 agent orchestrators"
for agent in claude antigravity codex cursor gemini generic kiro opencode; do
    src="$DELTA/code/internal/assets/$agent/sdd-orchestrator.md"
    dst="$TARGET/internal/assets/$agent/sdd-orchestrator.md"
    mkdir -p "$(dirname "$dst")"
    cp -f "$src" "$dst"
done
echo "    ✓ 8 orchestrators updated"

# Phase G — research skills (shared + primary + tertiary)
echo "==> Phase G: research skills"
mkdir -p "$TARGET/internal/assets/skills/_shared"
cp -f "$DELTA/code/internal/assets/skills/_shared/research-routing.md" \
      "$TARGET/internal/assets/skills/_shared/research-routing.md"

mkdir -p "$TARGET/internal/assets/skills/mcp-notebooklm-orchestrator"
cp -f "$DELTA/code/internal/assets/skills/mcp-notebooklm-orchestrator/SKILL.md" \
      "$TARGET/internal/assets/skills/mcp-notebooklm-orchestrator/SKILL.md"

mkdir -p "$TARGET/internal/assets/skills/mcp-context7-skill"
cp -f "$DELTA/code/internal/assets/skills/mcp-context7-skill/SKILL.md" \
      "$TARGET/internal/assets/skills/mcp-context7-skill/SKILL.md"

mkdir -p "$TARGET/internal/assets/claude/sdd-phase-protocols"
cp -f "$DELTA/code/internal/assets/claude/sdd-phase-protocols/sdd-explore.md" \
      "$TARGET/internal/assets/claude/sdd-phase-protocols/sdd-explore.md"
echo "    ✓ research routing + explore protocol updated"

# Phase F — mandatory skills (ripgrep + bash-expert)
echo "==> Phase F: mandatory skills"
mkdir -p "$TARGET/internal/assets/skills/ripgrep"
cp -f "$DELTA/code/internal/assets/skills/ripgrep/SKILL.md" \
      "$TARGET/internal/assets/skills/ripgrep/SKILL.md"

mkdir -p "$TARGET/internal/assets/skills/bash-expert"
cp -f "$DELTA/code/internal/assets/skills/bash-expert/SKILL.md" \
      "$TARGET/internal/assets/skills/bash-expert/SKILL.md"
echo "    ✓ ripgrep + bash-expert with bridge:always"

# Phase E — metering package (new)
echo "==> Phase E: metering package"
mkdir -p "$TARGET/internal/metering"
cp -f "$DELTA/code/internal/metering/session_stats.go"       "$TARGET/internal/metering/session_stats.go"
cp -f "$DELTA/code/internal/metering/session_stats_test.go"  "$TARGET/internal/metering/session_stats_test.go"
cp -f "$DELTA/code/internal/metering/pricing.go"             "$TARGET/internal/metering/pricing.go"
cp -f "$DELTA/code/internal/metering/hook.go"                "$TARGET/internal/metering/hook.go"

# Phase E — Claude canonical adapter_metering
cp -f "$DELTA/code/internal/agents/claude/adapter_metering.go" \
      "$TARGET/internal/agents/claude/adapter_metering.go"
echo "    ✓ metering pkg + claude adapter_metering"

# Phase D — Purge screens (new) + welcome (replace)
echo "==> Phase D: TUI purge screens"
mkdir -p "$TARGET/internal/tui/screens"
cp -f "$DELTA/code/internal/tui/screens/welcome.go"         "$TARGET/internal/tui/screens/welcome.go"
cp -f "$DELTA/code/internal/tui/screens/purge.go"           "$TARGET/internal/tui/screens/purge.go"
cp -f "$DELTA/code/internal/tui/screens/purge_confirm.go"   "$TARGET/internal/tui/screens/purge_confirm.go"
cp -f "$DELTA/code/internal/tui/screens/purge_result.go"    "$TARGET/internal/tui/screens/purge_result.go"

# Phase D — purge.go in uninstall component
cp -f "$DELTA/code/internal/components/uninstall/purge.go" \
      "$TARGET/internal/components/uninstall/purge.go"
echo "    ✓ welcome + 3 purge screens + purge.go"

echo
echo "================================================================"
echo "  Automated file-copy phase COMPLETE."
echo "================================================================"
echo
echo "MANUAL STEPS STILL REQUIRED — read each .patch in patches/ and"
echo "apply to the corresponding file:"
echo
for p in "$DELTA"/patches/*.{patch,md}; do
    [[ -f "$p" ]] || continue
    echo "  ✗ $(basename "$p")"
done
echo
echo "After applying the patches:"
echo "  1. bash $DELTA/scripts/generate-agent-metering.sh $TARGET"
echo "  2. cd $TARGET && go test ./..."
echo "  3. cd $TARGET && git diff --stat"
echo "  4. cd $TARGET && git add -A && git commit -m \"[IMP][v3.1] remediation: 6 findings + research routing\""
echo
