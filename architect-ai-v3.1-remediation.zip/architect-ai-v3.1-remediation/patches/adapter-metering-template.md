# Per-Agent Adapter Metering — Template & Generation Guide

**Target**: `internal/agents/{agent}/adapter_metering.go` for each non-Claude agent.
**What it does**: documents the per-agent JSON shape for usage extraction and how to generate the stubs with `scripts/generate-agent-metering.sh`.

The canonical reference is `internal/agents/claude/adapter_metering.go` (included in the package). All other agents follow the same pattern with field-path changes.

---

## Shape reference per agent

### Gemini

```go
type geminiUsageEnvelope struct {
    UsageMetadata struct {
        PromptTokenCount        int64 `json:"promptTokenCount"`
        CandidatesTokenCount    int64 `json:"candidatesTokenCount"`
        CachedContentTokenCount int64 `json:"cachedContentTokenCount"`
    } `json:"usageMetadata"`
    ModelVersion string `json:"modelVersion"`
}

func ExtractUsage(raw []byte) (metering.UsageDelta, error) {
    var env geminiUsageEnvelope
    if err := json.Unmarshal(raw, &env); err != nil {
        return metering.UsageDelta{}, err
    }
    return metering.UsageDelta{
        PromptTokens:     env.UsageMetadata.PromptTokenCount,
        CompletionTokens: env.UsageMetadata.CandidatesTokenCount,
        CachedTokens:     env.UsageMetadata.CachedContentTokenCount,
        // Gemini does not distinguish cache_creation from prompt tokens.
        CacheCreated:     0,
        Model:            env.ModelVersion,
    }, nil
}

func SessionHookEnabled() bool { return true }
```

### Codex (OpenAI)

```go
type codexUsageEnvelope struct {
    Usage struct {
        PromptTokens     int64 `json:"prompt_tokens"`
        CompletionTokens int64 `json:"completion_tokens"`
        PromptTokensDetails struct {
            CachedTokens int64 `json:"cached_tokens"`
        } `json:"prompt_tokens_details"`
    } `json:"usage"`
    Model string `json:"model"`
}

func ExtractUsage(raw []byte) (metering.UsageDelta, error) {
    var env codexUsageEnvelope
    if err := json.Unmarshal(raw, &env); err != nil {
        return metering.UsageDelta{}, err
    }
    return metering.UsageDelta{
        PromptTokens:     env.Usage.PromptTokens,
        CompletionTokens: env.Usage.CompletionTokens,
        CachedTokens:     env.Usage.PromptTokensDetails.CachedTokens,
        CacheCreated:     0,
        Model:            env.Model,
    }, nil
}

func SessionHookEnabled() bool { return true }
```

### Cursor

Cursor runs user-selected backends. The adapter delegates:

```go
func ExtractUsage(raw []byte) (metering.UsageDelta, error) {
    // Sniff the shape — a single byte tells us which parser to use.
    if bytes.Contains(raw, []byte(`"cache_read_input_tokens"`)) {
        return claude.ExtractUsage(raw)
    }
    if bytes.Contains(raw, []byte(`"usageMetadata"`)) {
        return gemini.ExtractUsage(raw)
    }
    if bytes.Contains(raw, []byte(`"prompt_tokens"`)) {
        return codex.ExtractUsage(raw)
    }
    return metering.UsageDelta{}, fmt.Errorf("cursor: unknown provider shape")
}

func SessionHookEnabled() bool { return true }
```

### Antigravity

```go
type antigravUsageEnvelope struct {
    Usage struct {
        PromptTokens     int64 `json:"prompt_tokens"`
        CompletionTokens int64 `json:"completion_tokens"`
        CachedTokens     int64 `json:"cached_tokens"`
    } `json:"usage"`
    Model string `json:"model"`
}

func ExtractUsage(raw []byte) (metering.UsageDelta, error) {
    var env antigravUsageEnvelope
    if err := json.Unmarshal(raw, &env); err != nil {
        return metering.UsageDelta{}, err
    }
    return metering.UsageDelta{
        PromptTokens:     env.Usage.PromptTokens,
        CompletionTokens: env.Usage.CompletionTokens,
        CachedTokens:     env.Usage.CachedTokens,
        CacheCreated:     0,
        Model:            env.Model,
    }, nil
}

func SessionHookEnabled() bool { return true }
```

### Kiro

Kiro speaks Claude natively (with its own auth). Delegate to Claude parser:

```go
func ExtractUsage(raw []byte) (metering.UsageDelta, error) {
    return claude.ExtractUsage(raw)
}

func SessionHookEnabled() bool { return true }
```

### OpenCode

Per-profile backend. The adapter reads the profile config to pick a parser:

```go
func ExtractUsage(raw []byte) (metering.UsageDelta, error) {
    // The profile name is injected into the adapter at construction.
    // Different profiles may use different providers.
    switch a.profileProvider {
    case "anthropic":
        return claude.ExtractUsage(raw)
    case "google":
        return gemini.ExtractUsage(raw)
    case "openai":
        return codex.ExtractUsage(raw)
    default:
        return metering.UsageDelta{}, nil
    }
}

func SessionHookEnabled() bool { return a.profileProvider != "" }
```

### Kilocode

```go
type kilocodeUsageEnvelope struct {
    Usage struct {
        PromptTokens     int64 `json:"prompt_tokens"`
        CompletionTokens int64 `json:"completion_tokens"`
        CachedTokens     int64 `json:"cached_tokens"`
    } `json:"usage"`
    Model string `json:"model"`
}
// ...same pattern as antigravity
```

### Qwen

Same shape as OpenAI/Codex:

```go
// Delegate to codex parser
func ExtractUsage(raw []byte) (metering.UsageDelta, error) {
    return codex.ExtractUsage(raw)
}

func SessionHookEnabled() bool { return true }
```

### VSCode & Windsurf

No direct usage visibility:

```go
func ExtractUsage(raw []byte) (metering.UsageDelta, error) {
    return metering.UsageDelta{}, nil
}

func SessionHookEnabled() bool { return false }
```

---

## Generate all stubs in one command

From the remediation package root:

```bash
bash scripts/generate-agent-metering.sh /path/to/architect-ai
```

The script stamps out `internal/agents/{agent}/adapter_metering.go` for each agent using the shapes above.

---

## Wiring at call sites

Each adapter's request path must call into the metering hook after receiving a response:

```go
// In the adapter's request handler (post-response):
claude.RecordResponse(rawBody)   // or gemini.RecordResponse(rawBody), etc.
```

The `RecordResponse` helper is defined per agent; it's a thin wrapper that
calls `ExtractUsage` and forwards to `metering.Current().Record(delta)`.
If the metering hook was never registered (unit tests, --no-metering mode),
it silently no-ops.
