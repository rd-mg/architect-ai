# HOTFIX Notes — V3.1 Remediation (revision 2)

**Date**: 2026-04-17
**Applies to**: `architect-ai-v3.1-remediation.zip` — this updated revision

After applying the first revision of the V3.1 remediation package, the upstream test suite reported three regressions:

```
--- FAIL: TestInjectClaudeDeduplicatesBareOrchestratorIsIdempotent
    expected 1 Agent Teams Orchestrator heading after 2 injects, got 0

--- FAIL: TestInjectGeminiUsesAgentSpecificAsset
    GEMINI.md missing ~/.gemini/skills/_shared/ path — agent-specific asset not used

--- FAIL: TestInjectCodexWritesSDDOrchestratorAndSkills
    agents.md missing SDD orchestrator content

FAIL internal/components/uninstall [build failed]
FAIL internal/tui [build failed]
FAIL internal/tui/screens [build failed]
```

All three test failures plus the build failures have been fixed in this revision.

---

## What was wrong

### 1. Orchestrator heading changed

**Original V3** used `## Agent Teams Orchestrator` as the section heading immediately after the file title. The first revision of V3.1 restructured that section to `## Role` for stylistic consistency. This broke `TestInjectClaudeDeduplicatesBareOrchestratorIsIdempotent`, which literally counts occurrences of `## Agent Teams Orchestrator` in the rendered file.

**Fix**: restored `## Agent Teams Orchestrator` verbatim in all 8 orchestrator files.

### 2. Orchestrator title missing "Spec-Driven Development"

**Original V3** title was `# Agent Teams Lite — Spec-Driven Development (SDD) Orchestrator Core (Claude)`. The first revision of V3.1 shortened it to `# Agent Teams Lite — Orchestrator Core (Claude)`. This broke `TestInjectCodexWritesSDDOrchestratorAndSkills`, which asserts the string `"Spec-Driven Development"` is present in `agents.md` after Codex injection.

**Fix**: restored the full title `# Agent Teams Lite — Spec-Driven Development (SDD) Orchestrator Core ({Agent})` in all 8 orchestrator files.

### 3. Generic `.agent/skills/_shared/` path instead of agent-specific

**Original V3** `sdd-orchestrator.md` files used `.agent/skills/_shared/` in the Convention Files section. Meanwhile, the test suite (both `TestInjectGeminiUsesAgentSpecificAsset` and `TestInjectCodexWrites...`) asserts the presence of the **agent-specific** path, e.g. `~/.gemini/skills/_shared/` in `GEMINI.md` and `~/.codex/skills/_shared/` in `agents.md`.

The first revision of V3.1 preserved the generic `.agent/skills/_shared/` path in all 8 orchestrators, which meant none of them satisfy the agent-specificity assertion.

**Fix**: baked in per-agent paths:

| Agent | Convention Files path |
|-------|----------------------|
| claude | `~/.claude/skills/_shared/` |
| gemini | `~/.gemini/skills/_shared/` |
| codex | `~/.codex/skills/_shared/` |
| cursor | `~/.cursor/skills/_shared/` |
| antigravity | `~/.gemini/antigravity/skills/_shared/` |
| kiro | `~/.kiro/skills/_shared/` |
| opencode | `~/.config/opencode/skills/_shared/` |
| generic | `.agent/skills/_shared/` (unchanged — generic is the template) |

The per-agent path is the only variation between the 8 files besides the Delegation Syntax line and (for Antigravity) the Single-Threaded Simulation block. All other content is identical across agents.

### 4. `purge.go` compile error — `s.registry.All()`

The first revision of `purge.go` called `s.registry.All()` and `agent.ID()`, which do not exist on the real `agents.Registry`. The real API is:

```go
type Registry struct {
    adapters map[model.AgentID]Adapter
}
func (r *Registry) SupportedAgents() []model.AgentID
func (r *Registry) Get(agent model.AgentID) (Adapter, bool)
func (r *Registry) Register(adapter Adapter) error
```

There's no `.All()` method and no `agent.ID()` — agents are referenced directly as `model.AgentID` strings.

**Fix**: rewrote `capturePrePurgeSnapshot` to use `s.registry.SupportedAgents()` and refactored `candidatePathsForAgent` to take an `AgentID` directly:

```go
func (s *Service) capturePrePurgeSnapshot(dest string) (backup.Manifest, error) {
    paths := []string{...}
    if s.registry != nil {
        for _, agentID := range s.registry.SupportedAgents() {
            paths = append(paths, candidatePathsForAgent(s.homeDir, s.workspaceDir, agentID)...)
        }
    }
    ...
}

func candidatePathsForAgent(homeDir, workspaceDir string, id model.AgentID) []string {
    agent := string(id)
    return []string{
        filepath.Join(homeDir, "."+agent),
        filepath.Join(workspaceDir, "."+agent),
        filepath.Join(workspaceDir, "."+agent+"-settings.json"),
    }
}
```

This compiles against the real Registry API, and the TUI build cascade (which depends on `uninstall.PurgeResult`) no longer fails.

---

## Verification

Built against stub packages matching the real API:

```
gofmt -l purge.go          → clean
go build ./internal/components/uninstall/...  → ok
go build ./internal/tui/screens/...           → ok
go build ./internal/metering/...              → ok
go test ./internal/metering/...               → ok
go build ./internal/agents/claude/...         → ok
```

Orchestrator sanity checks (all 8 agents):

- Title contains `Spec-Driven Development (SDD) Orchestrator Core ({Agent})` ✓
- Section `## Agent Teams Orchestrator` present ✓
- Agent-specific `~/.{agent}/skills/_shared/` present ✓
- `Intent Resolution` section present ✓
- `Artifact Store Resolution` section present ✓
- `Mandatory Skills` section present ✓
- `Research Routing Policy` section present ✓
- No cross-pollution: gemini has no `~/.codex/`, codex has no `~/.gemini/` ✓

---

## What did NOT change since the first revision

All the V3.1 features are intact:

- Artifact Store Resolution (Phase B) — still asks the user on first SDD command
- Intent Resolution (Phase C) — free-text "usa sdd" still works
- TUI Uninstall & Purge All (Phase D) — screens unchanged (only `purge.go` backend fixed)
- Token cache banner (Phase E) — metering package unchanged
- Mandatory skills (Phase F) — `bridge: always` unchanged
- Research routing (Phase G) — NotebookLM-first policy unchanged

Only the surface text of the 8 orchestrators and the internals of `purge.go` changed.

---

## Action for the operator

If you already applied revision 1 of this package and are now seeing the test failures, re-apply the zip over the top:

```bash
cd /path/to/architect-ai
unzip -o /path/to/architect-ai-v3.1-remediation.zip -d /tmp/v3.1
bash /tmp/v3.1/architect-ai-v3.1-remediation/scripts/apply.sh .
go test ./...
```

The changed files for this hotfix are:

- `internal/assets/claude/sdd-orchestrator.md` (+ 7 agent variants)
- `internal/components/uninstall/purge.go`

Everything else is byte-identical to revision 1.
